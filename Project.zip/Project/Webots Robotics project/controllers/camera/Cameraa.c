#include <webots/camera.h>
#include <webots/motor.h>
#include <webots/robot.h>

#define TIME_STEP 64
#define SPEED 5
#define THRESHOLD 100

WbDeviceTag camera;
WbDeviceTag left_motor;
WbDeviceTag right_motor;

int left_pixel_sum, right_pixel_sum;

void detect_color() {
  const unsigned char *image = wb_camera_get_image(camera);
  int width = wb_camera_get_width(camera);
  int height = wb_camera_get_height(camera);

  left_pixel_sum = 0;
  right_pixel_sum = 0;

  for (int i = width / 2 - THRESHOLD; i <= width / 2 + THRESHOLD; i++) {
    for (int j = height / 2 - THRESHOLD; j <= height / 2 + THRESHOLD; j++) {
      left_pixel_sum += image[width * j + i];
    }
  }

  for (int i = width / 2 + THRESHOLD; i >= width / 2 - THRESHOLD; i--) {
    for (int j = height / 2 - THRESHOLD; j <= height / 2 + THRESHOLD; j++) {
      right_pixel_sum += image[width * j + i];
    }
  }
}

void turn_left() {
  wb_motor_set_velocity(left_motor, -SPEED);
  wb_motor_set_velocity(right_motor, SPEED);
}

void turn_right() {
  wb_motor_set_velocity(left_motor, SPEED);
  wb_motor_set_velocity(right_motor, -SPEED);
}

void go_forward() {
  wb_motor_set_velocity(left_motor, SPEED);
  wb_motor_set_velocity(right_motor, SPEED);
}

int main() {
  wb_robot_init();

  camera = wb_robot_get_device("camera");
  wb_camera_enable(camera, TIME_STEP);

  left_motor = wb_robot_get_device("left wheel motor");
  right_motor = wb_robot_get_device("right wheel motor");

  wb_motor_set_position(left_motor, INFINITY);
  wb_motor_set_position(right_motor, INFINITY);

  while (wb_robot_step(TIME_STEP) != -1) {
    detect_color();

    if (left_pixel_sum > right_pixel_sum) {
      turn_right();
    } else if (right_pixel_sum > left_pixel_sum) {
      turn_left();
    } else {
      go_forward();
    }
  }

  wb_robot_cleanup();

  return 0;
}